package com.cg.university.beans;

public class Users {
	private String login_id;
	private String password;
	private String role;

	public Users() {

	}

	public Users(String login_id, String password, String role) {
		super();
		this.login_id = login_id;
		this.password = password;
		this.role = role;
	}

	public String getlogin_id() {
		return login_id;
	}

	public void setlogin_id(String login_id) {
		this.login_id = login_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Users [login_id=" + login_id + ", password=" + password + ", role=" + role + "]";
	}
}
