package com.cg.university.beans;

public enum Status {
	ACCEPTED, REJECTED, CONFIRMED;
}
