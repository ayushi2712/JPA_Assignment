package com.cg.university.beans;

import java.time.LocalDate;

public class ProgramSchedule {
	private String Scheduled_program_id;
	private String ProgramName;
	private String Location;
	private LocalDate start_date;
	private LocalDate end_date;
	private int sessions_per_week;

	public ProgramSchedule() {

	}

	public String getScheduled_program_id() {
		return Scheduled_program_id;
	}

	public void setScheduled_program_id(String Scheduled_program_id) {
		this.Scheduled_program_id = Scheduled_program_id;
	}

	public String getProgramName() {
		return ProgramName;
	}

	public void setProgramName(String ProgramName) {
		this.ProgramName = ProgramName;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String Location) {
		this.Location = Location;
	}

	public LocalDate getstart_date() {
		return start_date;
	}

	public void setstart_date(LocalDate start_date) {
		this.start_date = start_date;
	}

	public LocalDate getend_date() {
		return end_date;
	}

	public void setend_date(LocalDate end_date) {
		this.end_date = end_date;
	}

	public int getsessions_per_week() {
		return sessions_per_week;
	}

	public void setsessions_per_week(int sessions_per_week) {
		this.sessions_per_week = sessions_per_week;
	}

	public ProgramSchedule(String Scheduled_program_id, String ProgramName, String Location, LocalDate start_date,
			LocalDate end_date, int sessions_per_week) {
		super();
		this.Scheduled_program_id = Scheduled_program_id;
		this.ProgramName = ProgramName;
		this.Location = Location;
		this.start_date = start_date;
		this.end_date = end_date;
		this.sessions_per_week = sessions_per_week;
	}

	@Override
	public String toString() {
		return "ProgramsSchedule [Scheduled_program_id =" + Scheduled_program_id + ", ProgramName=" + ProgramName
				+ ", Location =" + Location + ", start_date =" + start_date + ", end_date =" + end_date
				+ ", sessions_per_week=" + sessions_per_week + "]";
	}
}
