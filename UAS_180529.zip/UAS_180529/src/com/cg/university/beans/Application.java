package com.cg.university.beans;

import java.time.LocalDate;

public class Application {
	private int Application_id;
	private String full_name;
	private LocalDate date_of_birth;
	private String highest_qualification;
	private int marks_obtained;
	private String goals;
	private String email_id;
	private String Scheduled_program_id;
	private String status;
	private LocalDate Date_Of_Interview;

	public Application() {

	}

	@Override
	public String toString() {
		return "Application [Application_id =" + Application_id + ", full_name =" + full_name + ", date_of_birth ="
				+ date_of_birth + ", highest_qualification =" + highest_qualification + ", marks_obtained ="
				+ marks_obtained + ", goals=" + goals + ", email_id=" + email_id + ", Scheduled_program_id="
				+ Scheduled_program_id + ", status=" + status + ", Date_Of_Interview=" + Date_Of_Interview + "]";
	}

	public Application(int Application_id, String full_name, LocalDate date_of_birth, String highest_qualification,
			int marks_obtained, String goals, String email_id, String Scheduled_program_id, String status,
			LocalDate Date_Of_Interview) {
		super();
		this.Application_id = Application_id;
		this.full_name = full_name;
		this.date_of_birth = date_of_birth;
		this.highest_qualification = highest_qualification;
		this.marks_obtained = marks_obtained;
		this.goals = goals;
		this.email_id = email_id;
		this.Scheduled_program_id = Scheduled_program_id;
		this.status = status;
		this.Date_Of_Interview = Date_Of_Interview;
	}

	public int getApplication_id() {
		return Application_id;
	}

	public void setApplication_id(int Application_id) {
		this.Application_id = Application_id;
	}

	public String getfull_name() {
		return full_name;
	}

	public void setfull_name(String full_name) {
		this.full_name = full_name;
	}

	public LocalDate getdate_of_birth() {
		return date_of_birth;
	}

	public void setdate_of_birth(LocalDate date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public String gethighest_qualification() {
		return highest_qualification;
	}

	public void sethighest_qualification(String highest_qualification) {
		this.highest_qualification = highest_qualification;
	}

	public int getmarks_obtained() {
		return marks_obtained;
	}

	public void setmarks_obtained(int marks_obtained) {
		this.marks_obtained = marks_obtained;
	}

	public String getGoals() {
		return goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	public String getemail_id() {
		return email_id;
	}

	public void setemail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getScheduled_program_id() {
		return Scheduled_program_id;
	}

	public void setScheduled_program_id(String Scheduled_program_id) {
		this.Scheduled_program_id = Scheduled_program_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getDate_Of_Interview() {
		return Date_Of_Interview;
	}

	public void setDate_Of_Interview(LocalDate Date_Of_Interview) {
		this.Date_Of_Interview = Date_Of_Interview;
	}

}
