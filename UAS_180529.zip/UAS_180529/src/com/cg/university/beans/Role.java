package com.cg.university.beans;

public enum Role {
	ADMIN, MAC;
}
