package com.cg.university.beans;

public class Participant {
	private String Roll_no;
	private String email_id;
	private int Application_id;
	private String Scheduled_program_id;

	public Participant() {
	
	}

	public Participant(String Roll_no, String email_id, int Application_id, String Scheduled_program_id) {
		super();
		this.Roll_no = Roll_no;
		this.email_id = email_id;
		this.Application_id = Application_id;
		this.Scheduled_program_id = Scheduled_program_id;
	}

	public String getRoll_no() {
		return Roll_no;
	}

	public void setRoll_no(String Roll_no) {
		this.Roll_no = Roll_no;
	}

	public String getemail_id() {
		return email_id;
	}

	public void setemail_id(String email_id) {
		this.email_id = email_id;
	}

	public int getApplication_id() {
		return Application_id;
	}

	public void setApplication_id(int Application_id) {
		this.Application_id = Application_id;
	}

	public String getScheduled_program_id() {
		return Scheduled_program_id;
	}

	public void setScheduled_program_id(String Scheduled_program_id) {
		this.Scheduled_program_id = Scheduled_program_id;
	}

	@Override
	public String toString() {
		return "Participant [Roll_no=" + Roll_no + ", email_id =" + email_id + ", Application_id =" + Application_id
				+ ", Scheduled_program_id=" + Scheduled_program_id + "]";
	}

}
