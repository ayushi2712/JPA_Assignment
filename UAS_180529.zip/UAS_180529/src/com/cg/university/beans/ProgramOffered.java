package com.cg.university.beans;

public class ProgramOffered {
	private String ProgramName;
	private String description;
	private String applicant_eligibility;
	private int duration;
	private String degree_certificate_offered;

	public ProgramOffered() {

	}

	public String getProgramName() {
		return ProgramName;
	}

	public void setProgramName(String ProgramName) {
		this.ProgramName = ProgramName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getapplicant_eligibility() {
		return applicant_eligibility;
	}

	public void setapplicant_eligibility(String applicant_eligibility) {
		this.applicant_eligibility = applicant_eligibility;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getdegree_certificate_offered() {
		return degree_certificate_offered;
	}

	public void setdegree_certificate_offered(String degree_certificate_offered) {
		this.degree_certificate_offered = degree_certificate_offered;
	}

	@Override
	public String toString() {
		return "ProgramsOffered [ProgramName=" + ProgramName + ", description=" + description
				+ ", applicant_eligibility=" + applicant_eligibility + ", duration=" + duration
				+ ", degree_certificate_offered=" + degree_certificate_offered + "]";
	}

	public ProgramOffered(String ProgramName, String description, String applicant_eligibility, int duration,
			String degree_certificate_offered) {
		super();
		this.ProgramName = ProgramName;
		this.description = description;
		this.applicant_eligibility = applicant_eligibility;
		this.duration = duration;
		this.degree_certificate_offered = degree_certificate_offered;
	}

}
