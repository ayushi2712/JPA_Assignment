package com.cg.university.pl;

import java.util.Scanner;

public class Client {
	UniversityService service=new UniversityServiceImpl();
	Scanner scanner=new Scanner(System.in); 

	//This method deal with the User as Applicant
	public void applicantDetails() throws InvalidMarksException  {

		String str;
	do {
		System.out.println("--------------------------------------------------------------------------------------------");
		System.out.println("Choose the action you want to do");
		System.out.println("--------------------------------------------------------------------------------------------");
		
		System.out.println("1.View All Programs");
		System.out.println("2.Check your application status");

		int choice;
		choice=scanner.nextInt();
		
		switch (choice) {
		case 1:
			Application application=new Application();
			
			//get list of offered program
			List<ProgramOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			
			//get list of scheduled program
			List<ProgramsSchedule> programs_schedule=new ArrayList<>();
			programs_schedule=service.getProgramSchedules();
			
			//Print all programs using offered programs and scheduled program as argument
			Utility.printAllPrograms(programs,programs_schedule);
			String wish;
			System.out.println("Do you wish to apply?[y|n]");
			wish=scanner.next();
			
			//break out of case:1 if user opt for n/N 
			if(wish.charAt(0)!='y' && wish.charAt(0)!='Y' ) break;
			
			System.out.println("Choose one program ID:");
			boolean pr;
			do {
				pr=false;
				
				int option=scanner.nextInt();
				
				for(ProgramsSchedule program :programs_schedule)
				{
					if(program.getScheduleProgramId()==option)
					{
						application.setScheduledProgramId(program.getScheduleProgramId());
						pr=true;
						break;
						
					}
					
					
				}
				if(!pr) System.out.println("Invalid program ID. Please try Again!");
				
				}while(!pr);
				
				System.out.println("Enter Full Name:");
				scanner.nextLine();
				String name=scanner.nextLine();
				//Prompt Full Name
				if(Utility.isValidName(name))
				application.setFullName(name);
				else
				{
					String Name;
					do
					{
					System.out.println("Please enter valid name!");
					 Name=scanner.nextLine();				
					
					}while(!Utility.isValidName(Name));
					
					application.setFullName(Name);
				}
				
				//Prompt Date of Birth
				System.out.println("Enter date of birth [dd-mm-yyyy]");
			
				String dob=scanner.next();
				String[] dob2;
				if(Utility.isValidDob(dob)) {
					String[] dob1=dob.split("-");
				application.setDateOfBirth(LocalDate.of(Integer.parseInt(dob1[2]), Integer.parseInt(dob1[1]), Integer.parseInt(dob1[0])));
				}else
				{
					boolean flag=true;
				
					do
					{
					System.out.println("please enter valid date!");
					
					 dob=scanner.next();
					 dob2=dob.split("-");
					if(!Utility.isValidDob(dob))
						flag=false;

					else flag=true;

					}while(!flag);
					
					application.setDateOfBirth(LocalDate.of(Integer.parseInt(dob2[2]), Integer.parseInt(dob2[1]), Integer.parseInt(dob2[0])));

				}
				
				
				//Prompt for Qualification to be one of[10th/12th/UG/PG]
				System.out.println("Enter Highest Qualification [10th/12th/UG/PG]");
				String qualify=scanner.next();
				if(Utility.verifyQualify(qualify))
				{application.setHighestQualification(qualify);}
				else
				{
					boolean flag=true;
				
					do
					{
					System.out.println("please enter valid qualification!");
					
					 qualify=scanner.next();
					
					if(!Utility.verifyQualify(qualify))
						flag=false;
					else
						flag=true;
					
					
					}while(!flag);
					
					application.setHighestQualification(qualify);
					
				}
				
				//Prompt Marks obtained
				System.out.println("Enter marks obtained");
				
				application.setMarksObtained(scanner.nextInt());
				
				
				while(!service.isVAlidMarks(application.getMarksObtained()))
				{
					System.out.println("Invalid marks! Enter marks obtained");
					
					application.setMarksObtained(scanner.nextInt());
				}
				
				//Prompt Goals
				System.out.println("Enter your goals");
				scanner.nextLine();
				application.setGoals(scanner.nextLine());
				
				//Prompt Email Id
				System.out.println("Enter your EmailID");
				String email=scanner.next();
				if(Utility.isValidEmail(email))
				application.setEmailId(email);
				else
				{
					boolean flag=true;
					String email1;
					do
					{
					System.out.println("please enter valid email!");
					

					 email1=scanner.next();
					
					if(!Utility.isValidEmail(email1))	
						flag=false;
					
					else
					     flag=true;

					}while(!flag);
					
					
					application.setEmailId(email1);
				}
				
				//Fresh applicant status is Applied by default
				application.setStatus(Status.APPLIED);
				
				
				//apply for the corresponding program return type Application Object
				Application application1=service.apply(application);
				
				System.out.println("Application submitted successfully with Applicant ID: \""
						+application1.getApplicationId()+"\" "
								+ "Status:\""+application1.getStatus()+"\"");
				
			
			break;
		case 2:
			//case to print Status of the applicant based on the applicant Id
			System.out.println("Enter the Applicant Id:");
			int appId=scanner.nextInt();
			
			String status=service.getStatus(appId);
			if(status==null) System.out.println("Invalid Application ID");
			else System.out.println("Your Application is "+status);
			break;
		default:
			System.out.println("Invalid Option!!");
			break;
		}
		System.out.println(" Applicant Do you want to continue? [y/n]");
		str=scanner.next();
	}while(str.charAt(0)=='y' || str.charAt(0)=='Y');
	}


	//This method deal with the User as the Member of Admission Committee(MAC)
	public void MACLogin() {
		String str;

		System.out.println("--------------------------------------------------------------------------------------------");
		System.out.println("\t\t****MAC LOGIN****");
		System.out.println("--------------------------------------------------------------------------------------------");
		
		System.out.println("Enter the Username: ");
		int username=scanner.nextInt();
		
		System.out.println("Enter the password:");
		String pwd=scanner.next();
		boolean bool=service.isVAlidMACLogin(username,pwd);
		do {
			//Continue only if MAC is valid user
		if(bool)
		{
			List<ProgramsOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			System.out.println("Enter Program Id: ");
			ProgramsOffered program=new ProgramsOffered();
				int programId=scanner.nextInt();
				
				boolean b=service.isValidProgram(programId);
				if(b)
				{
					System.out.println("Eligibility for the program is: "+service.getEligibilityCriteria(programId));
				List<Application> applications=service.getAllApplicants(programId);
				//System.out.println(applications);
				int cnt=0;
			if(!applications.isEmpty())
			{	
				for(Application application:applications)
				{
					if(application.getStatus().toString()!="REJECTED" && application.getStatus().toString()!="CONFIRMED")
					{
						System.out.println("Applicant ID\t Full Name \t DOB\t\tHighest Qualification\tMarks Obtained\tGoals\tEmail ID\tStatus");
						System.out.println("----------------------------------------------------------------------------------------------------------------------------");
						
			
					System.out.println("\t"+application.getApplicationId()+"\t"+application.getFullName()+"\t\t"+application.getDateOfBirth()+"\t\t"+application.getHighestQualification()+"\t\t"
							+application.getMarksObtained()+"\t"+application.getGoals()+"\t"+application.getEmailId()+"\t"+application.getStatus());
						if(application.getStatus()==Status.APPLIED)
						{
								System.out.println("1. Accept \n2. Reject");
								int choice=scanner.nextInt();
								switch(choice)
								{
								case 1: System.out.println("Give the date of Interview [dd-mm-yyyy]");	
											String[] date= scanner.next().split("-");
											LocalDate interviewDate=LocalDate.of(Integer.parseInt(date[2]), Integer.parseInt(date[1]), Integer.parseInt(date[0]));
											application.setStatus(Status.ACCEPTED);
											application.setDateOfInterview(interviewDate);
											service.updateApplicationStatus(application);
											break;
								case 2:
										application.setStatus(Status.REJECTED);
										service.updateApplicationStatus(application);
										break;
								default: System.out.println("Invalid choice");
								break;
								
								}
						}
						else if(application.getStatus()==Status.ACCEPTED)
						{
							System.out.println("1. Confirm \n2. Reject");
							int choice=scanner.nextInt();
							switch(choice)
							{
							case 1:		application.setStatus(Status.CONFIRMED);
										
										service.updateApplicationStatus(application);
										
										Participant participant=new Participant();
										participant.setApplication(application);
										participant.setEmailId(application.getEmailId());
										participant.setRollNo(Utility.generatevalue());
										participant.setScheduledProgramId(application.getScheduledProgramId());
										service.createParticipant(participant);
										break;
							case 2:
									application.setStatus(Status.REJECTED);
									service.updateApplicationStatus(application);
									break;
									
							default: System.out.println("Invalid choice!!");
							
							}
						}
						
					}
					else
						cnt++;
				}
				if(cnt>0) System.out.println("No new Applicants to approve!");
				
			}
			else
			
				System.out.println("There are no applicants for this program!");

	
		}
		else
			System.out.println("Program does not exist!");
		
		}
		System.out.println("MAC Do you want to continue?[y/n]");
		str=scanner.next();
	}while(str.charAt(0)=='y' || str.charAt(0)=='Y');
	
	}

	public void AdminLogin() {
		String str;

		System.out.println("--------------------------------------------------------------------------------------------");
		System.out.println("\t\t****Admin LOGIN****");
		System.out.println("--------------------------------------------------------------------------------------------");
		
		System.out.println("Enter the Username: ");
		int username=scanner.nextInt();
		
		System.out.println("Enter the password:");
		String pwd=scanner.next();
		if(service.isVAlidAdminLogin(username,pwd))
		{
			
		String choice;
		do {
			System.out.println("--------------------------------------------------------------------------------------------");
			System.out.println("Choose the action you want to do");
			System.out.println("--------------------------------------------------------------------------------------------");
			
			System.out.println("1. Update information of the programs offer by the university");
			System.out.println("2. Add programs offered by the university");
			System.out.println("3. Delete programs offered by the university");//done
			
			System.out.println("4. Add schedules of the programs offered by the university");//done
			System.out.println("5. Delete schedules of the programs offered by the university");//done
			System.out.println("6. View List of applicants scheduled program.");//done
			System.out.println("Enter choice: ");
			int option=scanner.nextInt();
			String programName;
			String description;
			 String applicantEligibility ;
			 int duration;
			 String degreeCertificateOffered ;
			switch(option)
			{
				case 1://Update information of the programs offer by the university
					System.out.println("Enter Program Name: ");
					programName=scanner.next();
					ProgramsOffered programsOffered=service.isValidProgramOffered(programName);
					if(programsOffered!=null)
					{
						description=programsOffered.getDescription();
						applicantEligibility=programsOffered.getApplicantEligibility();
						duration=programsOffered.getDuration();
						degreeCertificateOffered=programsOffered.getDegreeCertificateOffered();
						boolean update=true;
						while(update)
						{
							System.out.println("1. Update description");
							System.out.println("2. Update eligibility criteria");
							System.out.println("3. Update duration");
							System.out.println("4. Update Certificate offered");
							System.out.println("5. No update");
							int i=scanner.nextInt();
							scanner.nextLine();
							switch(i)
							{
							case 1:
								System.out.println("Enter description for update: ");
								description=scanner.nextLine();
								break;
							case 2:
								System.out.println("Enter eligibility criteria for update: ");
								applicantEligibility=scanner.nextLine();
								break;
							case 3:
								System.out.println("Enter program duration for update: ");
								duration=scanner.nextInt();
								scanner.nextLine();
								break;
							case 4:
								System.out.println("Enter certificate offered to be updated: ");
								degreeCertificateOffered=scanner.nextLine();
								break;
							case 5:
								update=false;
								break;
							default:
								System.out.println("Not a valid choice!!");
								break;
							}
						}
						programsOffered=new ProgramsOffered(programName,description,applicantEligibility,duration,degreeCertificateOffered);
						service.updateProgramsOffered(programsOffered);
					}
					else {
						System.out.println("Invalid program name!");
					}
					break;
				case 2://add program offered 
					System.out.println("Enter Program Offered information to be added-- ");
					System.out.println("Enter Program Name: ");
					programName=scanner.next();
					scanner.nextLine();
					System.out.println("Enter Description: ");
					description=scanner.nextLine();
					System.out.println("Enter Eligibility Criterea: ");
					applicantEligibility=scanner.nextLine();
					System.out.println("Enter duration of program: ");
					duration=scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter Certificate offered: ");
					degreeCertificateOffered=scanner.nextLine();
					programsOffered=new ProgramsOffered(programName,description,applicantEligibility,duration,degreeCertificateOffered);
					service.addProgramsoffered(programsOffered);
					break;
				case 3://Delete programs offered by the university
					System.out.println("Enter name of program offered: ");
					programName=scanner.next();
					if(service.isValidProgramOffered(programName)!=null)
					{
						service.deleteProgramOffered(programName);
					}else
					{
						System.out.println("Program does not exists!");
					}
					break;
				case 4://Add schedules of the programs offered by the university
					System.out.println("Enter name of program offered to be scheduled: ");
					programName=scanner.next();
					if(service.isValidProgramOffered(programName)!=null)
					{
						ProgramsSchedule programSchedule=new ProgramsSchedule();
						System.out.println("Enter program ID: ");
						int scheduleProgramId=scanner.nextInt();
						programSchedule.setScheduleProgramId(scheduleProgramId);
						
						programSchedule.setProgramName(programName);
						
						System.out.println("Enter program location: ");
						String location=scanner.next();
						programSchedule.setLocation(location);
						
						System.out.println("Enter start date [dd-mm-yyyy]");
						String start=scanner.next();
						String[] start1=start.split("-");
						programSchedule.setStartDate(LocalDate.of(Integer.parseInt(start1[2]), Integer.parseInt(start1[1]), Integer.parseInt(start1[0])));
						//System.out.println(programSchedule.getStartDate());
						System.out.println("Enter end date [dd-mm-yyyy]");
						String end=scanner.next();
						String[] end1=end.split("-");
						programSchedule.setEndDate(LocalDate.of(Integer.parseInt(end1[2]), Integer.parseInt(end1[1]), Integer.parseInt(end1[0])));
						//System.out.println(programSchedule.getEndDate());
						System.out.println("Enter session per week: ");
						int sessionPerWeek=scanner.nextInt();
						programSchedule.setSessionPerWeek(sessionPerWeek);
						
						service.addProgramScheduled(programSchedule);
						
					}
					else {
						System.out.println("Program does not exists!");
					}
					break;
				case 5://Delete schedules of the programs offered by the university
					System.out.println("Enter name of program scheduled: ");
					programName=scanner.next();
					if(service.isValidProgramScheduled(programName))
					{
						service.deleteProgramScheduled(programName);
					}
					else
					{
						System.out.println("Program does not exists!");
					}
					break;
				case 6://View List of applicants scheduled program
					System.out.println("Enter program ID: ");
					int programId=scanner.nextInt();
					
						List<Application> applications=service.getAllApplicantsAdmin(programId);
						//System.out.println(applications);
						if(applications.isEmpty())
							System.out.println("No application exists for program ID: "+programId);
						else
							Utility.printAllApplications(applications);
					
					
					break;
				default:
					System.out.println("Invalid Choice!!!");

			}
			System.out.println("Admin, do you want to continue? [y/n]");
			choice=scanner.next();
		}while(choice.charAt(0)=='y' || choice.charAt(0)=='Y');
	
	}
	}
	
}

}
