package com.cg.university.exception;

public class UniversityException extends Exception {
	String message;

	public UniversityException(String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
