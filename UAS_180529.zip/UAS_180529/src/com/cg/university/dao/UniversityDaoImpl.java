package com.cg.university.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.employee.exception.EmployeeException;
import com.cg.logger.MyLogger;
import com.cg.university.beans.Application;
import com.cg.university.beans.ProgramOffered;
import com.cg.university.beans.ProgramSchedule;
import com.cg.university.beans.Status;
import com.cg.university.beans.Users;
import com.cg.university.exception.UniversityException;
import com.cg.university.util.DBUtil;

public class UniversityDaoImpl implements UniversityDao {
	Connection con;
	Logger logger;

	public UniversityDaoImpl() {
		con = DBUtil.getConnect();// connection is obtained using DBUtil
		logger = MyLogger.getLogger();
	}

	@Override
	public ArrayList<ProgramOffered> getAllProgramOffered() throws UniversityException {

		ArrayList<ProgramOffered> program = new ArrayList<ProgramOffered>();

		String qry = "SELECT * FROM Programs_Offered";

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while (rs.next()) {
				String ProgramName = rs.getString(1);
				String description = rs.getString(2);
				String applicant_eligibility = rs.getString(3);
				int duration = rs.getInt(4);
				String degree_certificate_offered = rs.getString(5);
				ProgramOffered p1 = new ProgramOffered(ProgramName, description, applicant_eligibility, duration,
						degree_certificate_offered);
				program.add(p1);
			}

		} catch (SQLException e) {
			logger.error("error" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return program;
	}

	@Override
	public ProgramOffered isValidProgramOffered(String programName) throws UniversityException{
		ProgramOffered programOffered = null;
		String qry = "SELECT * FROM Programs_Offered WHERE ProgramName =?";
		try {
			PreparedStatement pstmt= con.prepareStatement(qry);
			 pstmt.setString(1, programName);
	    	   ResultSet rs= pstmt.executeQuery();
			if (rs.next()) {

				String ProgramName = rs.getString(1);
				String description = rs.getString(2);
				String applicant_eligibility = rs.getString(3);
				int duration = rs.getInt(4);
				String degree_certificate_offered = rs.getString(5);
				programOffered = new ProgramOffered(ProgramName,description,applicant_eligibility,duration,degree_certificate_offered);
			}
			else
	    	      throw new UniversityException("Program"+programName+"not offered");  
			
		} catch (SQLException e) {
			logger.error("error" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return programOffered;
	}

	@Override
	public boolean isValidProgram(int programId) throws UniversityException {
		String qry = "SELECT * FROM Programs_Scheduled WHERE Scheduled_program_id =? ";

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			stmt.setInt(1, programId);

			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			logger.error("error" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return false;
	}

	@Override
	public ArrayList<ProgramSchedule> getProgramSchedule() throws UniversityException {
		ArrayList<ProgramSchedule> programs = new ArrayList<ProgramSchedule>();

		String qry = "SELECT * FROM Programs_Scheduled";

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while (rs.next()) {

				String Scheduled_program_id = rs.getString(1);
				String ProgramName = rs.getString(2);
				String Location = rs.getString(3);
				java.sql.Date sdate = rs.getDate(4);
				LocalDate start_date = sdate.toLocalDate();
				java.sql.Date edate = rs.getDate(5);
				LocalDate end_date = edate.toLocalDate();
				int sessions_per_week = rs.getInt(6);
				ProgramSchedule p2 = new ProgramSchedule(Scheduled_program_id, ProgramName, Location, start_date,
						end_date, sessions_per_week);
				programs.add(p2);
			}
		} catch (SQLException e) {
			logger.error("error" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return programs;

	}

	@Override
	public boolean isValidProgramScheduled(String programName) {
		String qry = "SELECT * FROM Programs_Scheduled WHERE ProgramName=? ";

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			stmt.setString(1, programName);

			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			throw new UniversityException(e.getMessage());
		}
		return false;
	}

	@Override
	public Application Apply(Application application) {
		Application application1 = new Application();
		String qry = "INSERT INTO Application(full_name, date_of_birth, highest_qualification, marks_obtained, goals, email_id, Scheduled_program_id, status) "
				+ "values(?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt= con.prepareStatement(qry);
			ResultSet rs = pstmt.executeQuery(qry);
			String full_name = rs.getString(1);
			java.sql.Date bdate = rs.getDate(2);
			LocalDate date_of_birth = bdate.toLocalDate();
			String highest_qualification = rs.getString(3);
			int marks_obtained = rs.getInt(4);
			String goals = rs.getString(5);
			String email_id = rs.getString(6);
			String Scheduled_program_id = rs.getString(7);
			String Status = rs.getString(8);

			int flag = stmt.executeUpdate();
			if (flag > 0) {

				UniversityDaoImpl.logger.info("Application Record inserted successfully");
				String sql1 = "select application_id, scheduled_program_id, status from application";
				PreparedStatement pst1 = connection.prepareStatement(sql1);

				ResultSet rs = pst1.executeQuery();

				while (rs.next()) {
					application1.setApplication_id(rs.getInt(1));
					application1.setScheduled_program_id(rs.getInt(2));
					application1.setStatus(String.valueOf(rs.getString(3)));

				}

			}

		} catch (SQLException e) {
			throw new UniversityException(e.getMessage());
		}

		return application1;
	}

	@Override
	public String getStatus(int appId) throws UniversityException {
		Status status = getStatus();
		String qry = "SELECT status FROM Application WHERE application_id=?";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);

			while (rs.next()) {
				stmt.setInt(1, appId);
				return rs.getString(1);
			}

		} catch (SQLException e) {
			logger.error("error"+e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return null;
	}

	@Override
	public ArrayList<Users> getUserDetails() throws UniversityException{
		ArrayList<Users> users = new ArrayList<Users>();

		String qry = "SELECT * FROM Users";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while (rs.next()) {

				String login_id = rs.getString(1);
				String password = rs.getString(2);
				String role = rs.getString(3);
				Users u= new Users(login_id,password,role);
				users.add(u);
			}

		} catch (SQLException e) {
			logger.error("error"+e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return users;
	}

	@Override
	public ArrayList<Application> getAllApplicant(int programId) throws UniversityException{
		ArrayList<Application> applications = new ArrayList<Application>();

		String qry = "SELECT * FROM Application WHERE Scheduled_program_id=? and " + "(Date_Of_Interview is null "
				+ "or Date_Of_Interview <=now()) and (status!=\"CONFIRMED\" or status!=\"REJECTED\")";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			//stmt.setInt(1, programId);
			while (rs.next()) {

				int Application_id = rs.getInt(1);
				String full_name = rs.getString(2);
				java.sql.Date bdate = rs.getDate(3);
				LocalDate dob = bdate.toLocalDate();
				String highest_qualification = rs.getString(4);
				int marks_obtained = rs.getInt(5);
				String goals = rs.getString(6);
				String email_id = rs.getString(7);
				String Scheduled_program_id = rs.getString(8);
				String status = rs.getString(9);
				java.sql.Date idate = rs.getDate(3);
				LocalDate Date_Of_Interview = idate.toLocalDate();
				Application app= new Application(Application_id,full_name,dob,highest_qualification,marks_obtained,goals,email_id,Scheduled_program_id,status,Date_Of_Interview);
				applications.add(app);				
			}

		} catch (SQLException e) {
			logger.error("error"+e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return applications;
	}
}
