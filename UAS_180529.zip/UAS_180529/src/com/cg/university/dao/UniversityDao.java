package com.cg.university.dao;

import java.util.List;


import com.cg.university.beans.Application;
import com.cg.university.beans.ProgramOffered;
import com.cg.university.beans.ProgramSchedule;
import com.cg.university.beans.Users;
import com.cg.university.exception.UniversityException;

public interface UniversityDao {

	public List<ProgramOffered> getAllProgramOffered() throws UniversityException;// list of all programs

	public ProgramOffered isValidProgramOffered(String programName) throws UniversityException;

	public boolean isValidProgram(int programId) throws UniversityException;// program is in the list

	public List<ProgramSchedule> getProgramSchedule() throws UniversityException;

	public boolean isValidProgramScheduled(String programName) throws UniversityException;

	public Application Apply(Application application) throws UniversityException;
	public String getStatus(int appId) throws UniversityException;// viewing the status of the applicant

	public List<Users> getUserDetails() throws UniversityException;

	public List<Application> getAllApplicant(int programId) throws UniversityException;

}
