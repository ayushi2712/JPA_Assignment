package com.cg.university.test;

public class UniversityTest {
	@Mock
	private I_UAS_Dao applicationdao;
	
	private UAS_Service_Impl service;
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		service = new UAS_Service_Impl(applicationdao);
	}
	
	
	
	@Test(expected=InvalidMarksException.class)
	public void test_invalid_marks() throws InvalidMarksException
	{
		int marks=-100;
		
		
		service.isVAlidMarks(marks);
		
	}
	
	//Mockito verification for adding applicant
	@Test
	public void test_acc()
	{
		Application application1=new Application();
	
   
		application1.setApplicationId(1);
		application1.setFullName("akhil");
		application1.setDateOfBirth(LocalDate.of(2000, 10, 10));
		application1.setHighestQualification("12th");
		application1.setMarksObtained(100);
		application1.setGoals("towin");
		application1.setEmailId("akhil@gmail");
		application1.setScheduledProgramId(1001);
		application1.setStatus(Status.APPLIED);
		application1.setDateOfInterview(LocalDate.of(2018, 10, 10));
	    
	    Mockito.when(applicationdao.apply(application1)).thenReturn(application1);
	    
	    
	    service.apply(application1);
	    
	    Mockito.verify(applicationdao).apply(application1);
	    
	    
	}
	
	
	//Mockito verification for createParticipant
	
	
	
	
	//Test case for updateApplicationStatus
	@Test
	public void test_update_Status()
	{

		Application application1=new Application();
		
		   
		application1.setApplicationId(1);
		application1.setFullName("Annapoorna");
		application1.setDateOfBirth(LocalDate.of(1996, 10, 10));
		application1.setHighestQualification("UG");
		application1.setMarksObtained(100);
		application1.setGoals("to win");
		application1.setEmailId("annapoorna@gmail.com");
		application1.setScheduledProgramId(1001);
		application1.setStatus(Status.APPLIED);
		application1.setDateOfInterview(LocalDate.of(2018, 10, 10));
		
		  Mockito.when(applicationdao.updateApplicationStatus(application1)).thenReturn(true);
		  
		    
		    
		    service.apply(application1);
		    
		    Mockito.verify(applicationdao).apply(application1);
		
	}
	
}

}
