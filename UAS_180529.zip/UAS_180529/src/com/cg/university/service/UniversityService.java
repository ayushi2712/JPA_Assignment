package com.cg.university.service;

import java.util.List;

import com.cg.university.beans.Application;
import com.cg.university.beans.ProgramOffered;
import com.cg.university.beans.ProgramSchedule;
import com.cg.university.beans.Users;

public interface UniversityService {
	public List<ProgramOffered> getAllProgramsOffered();

	public ProgramOffered isValidProgramOffered(String programName);

	public boolean isValidProgram(int programId);

	public List<ProgramSchedule> getProgramSchedule();

	public boolean isValidProgramSchedule(String programName);

	public Application Apply(Application application);

	public String getApplicationStatus(int appId);

	public List<Users> getUserDetails();

	public List<Application> getAllApplicant(int programId);

}
