package com.cg.university.service;

public class UniversityServiceImpl implements UniversityService {
	
final static Logger logger=Logger.getLogger(UAS_Dao_Impl.class);
	
	ApplicationDao appdao=new ApplicationDao(); 
	I_UAS_Dao uasDao=new UAS_Dao_Impl();


	public UAS_Service_Impl(ApplicationDao applicationdao) {
		// TODO Auto-generated constructor stub
		
		this.appdao=applicationdao;
	}

	public UAS_Service_Impl() {
		// TODO Auto-generated constructor stub
	}

	public UAS_Service_Impl(I_UAS_Dao applicationdao) {
		// TODO Auto-generated constructor stub
		this.uasDao=applicationdao;
	}

	@Override
	public List<ProgramsOffered> getAllProgramsOffered() {
		// TODO Auto-generated method stub
		return uasDao.getAllProgramsOffered();
	}

	@Override
	public String getStatus(int appId) {
		
		return uasDao.getStatus(appId);
	}

	@Override
	public Application apply(Application application) {
		return(uasDao.apply(application));
		
	}

	@Override
	public boolean isVAlidMACLogin(int username, String pwd) {
		
		List<Users> users= uasDao.getUserDetails();
		//System.out.println(users);
		for(Users user1:users)
		{
			if(user1.getLoginId()==username && user1.getPassword().equals(pwd) && user1.getRole()==Role.MAC)
			{
				System.out.println("You are successfully loggedIn");
				return true;
			}
			
			
		}
		System.out.println("invalid");
		return false;
		
	}

	
	
	@Override
	public boolean isVAlidAdminLogin(int username, String pwd) {
		
		List<Users> users= uasDao.getUserDetails();
		//System.out.println(users);
		for(Users user1:users)
		{
			if(user1.getLoginId()==username && user1.getPassword().equals(pwd) && user1.getRole()==Role.ADMIN)
			{
				System.out.println("You are successfully loggedIn");
				return true;
			}
			
			
		}
		System.out.println("invalid");
		return false;
		
	}
	@Override
	public List<Application> getAllApplicants(int programId) {
		return uasDao.getAllApplicants(programId);
		
	}

	@Override
	public boolean updateApplicationStatus(Application application) {
		return ( uasDao.updateApplicationStatus(application));
		
	}

	@Override
	public boolean createParticipant(Participant participant) {
		// TODO Auto-generated method stub
		return(uasDao.createParticipant(participant));
		
	}

	@Override
	public boolean isVAlidMarks(int marksObtained) {
	
		
		try {
				if(marksObtained<0 ||marksObtained>100)
				{
					
					throw new InvalidMarksException("Marks can't be negative or greater than 100");
					 
					
				}
		}
		catch(InvalidMarksException e)
		{
			
			
			logger.error(e.getMessage(),e);
			
			return false;
			//e.printStackTrace();
			
		}
		return true;
	}

	@Override
	public boolean isValidProgram(int programId) {
		
		return uasDao.isValidProgram(programId);
	}

	@Override
	public String getEligibilityCriteria(int programId) {
		
		return uasDao.getEligibilityCriteria(programId);
	}

	@Override
	public List<ProgramsSchedule> getProgramSchedules() {
		// TODO Auto-generated method stub
		return uasDao.getProgramSchedules();
	}

	@Override
	public ProgramsOffered isValidProgramOffered(String programName) {
				return uasDao.isValidProgramOffered(programName);
	}

	@Override
	public void updateProgramsOffered(ProgramsOffered programsOffered) {
	
	uasDao.updateProgramsOffered(programsOffered);
		
	}

	@Override
	public void addProgramsoffered(ProgramsOffered programsOffered) {
		// TODO Auto-generated method stub
		uasDao.addProgramsOffered(programsOffered);
	}

	@Override
	public void deleteProgramOffered(String programName) {
		uasDao.deleteProgramOffered(programName);
		
	}

	@Override
	public boolean isValidProgramScheduled(String programName) {
		return uasDao.isValidProgramScheduled(programName);
	}

	@Override
	public void deleteProgramScheduled(String programName) {
		uasDao.deleteProgramScheduled(programName);
		
	}

	@Override
	public void addProgramScheduled(ProgramsSchedule programSchedule) {
		// TODO Auto-generated method stub
		uasDao.addProgramScheduled(programSchedule);
	}

	@Override
	public List<Application> getAllApplicantsAdmin(int programId) {
		// TODO Auto-generated method stub
		return uasDao.getAllApplicantsAdmin(programId);
	}

}

}
