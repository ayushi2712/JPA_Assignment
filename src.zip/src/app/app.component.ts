import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { HeaderComponent} from './header/header.component';
import { EmployeeService } from './employee/employee/employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit{
  
  title = 'ecomApp';
  @ViewChild(HeaderComponent) headerComponent : HeaderComponent;

  constructor(private empService: EmployeeService){}

  ngOnInit() {
  }

  addEmployee(){
    this.empService.addEmployee();
  }

  ngAfterViewInit(){
    this.headerComponent.header = `Welcome to ${this.title}`;
  }
  
}
