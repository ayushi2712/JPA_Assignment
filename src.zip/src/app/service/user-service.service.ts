import { Injectable } from '@angular/core';
import{ UserModel} from '../model/UserModel';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
userList : UserModel[] = [];

  constructor() { }

  insertUser(user: UserModel){
    this.userList.push(user);
  }

  getList(): UserModel[] {
return this.userList;
  }

  deleteUser(index : number){
    return this.userList.splice(index,1);
  }
}
