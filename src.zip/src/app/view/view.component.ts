import { Component, OnInit } from '@angular/core';
import { UserModel } from '../model/UserModel';
import { UserServiceService } from '../service/user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  userList: UserModel[] = [];

  constructor(private userService: UserServiceService, private router: Router) {

  }

  ngOnInit() {
    this.userList = this.userService.getList();
  }

  delete(index: number) {
    var ans = confirm("Are You Sure You Want To Delete?")
    if (ans) {
      this.userService.deleteUser(index);
    }
  }
}
