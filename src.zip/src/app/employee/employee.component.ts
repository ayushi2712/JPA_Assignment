import { Component, OnInit, DoCheck, SkipSelf, Self } from '@angular/core';
import {IEmployee} from './iemployee';
import { EmployeeService } from './employee/employee.service';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeService]
})
export class EmployeeComponent implements OnInit, DoCheck {

  empName: string ='Amit';
  department ='IT';

  detail : IEmployee ={
    age: 24,
    id :1,
    name:'Akshay',
    dob : new Date('19-Jan-1996')
  };

  list: Array<IEmployee>=[]

  isValid = false;
  constructor(@Self() private empService : EmployeeService) { }

  ngOnInit() {
    this.list =this.empService.getEmployeeList();
  }

  ngDoCheck(){
    console.log('Change event is called')
  }

  toggle(){
    this.isValid =!this.isValid;
  }
  recieveFromChild(employee: IEmployee){
    console.log(employee);
  }
  refresh(){
    this.list=[{
      age: 26,
    id :1,
    name:'sushant',
    dob : new Date('19-Jan-1996')
    },
    {
      age: 25,
    id :2,
    name:'Akshay',
    dob : new Date('19-Jan-1996')
    },
    {
    age: 26,
    id :3,
    name:'jay',
    dob : new Date('19-Jan-1996')
    }

    ]
  }
}
