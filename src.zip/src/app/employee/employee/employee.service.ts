import { Injectable } from '@angular/core';
import { IEmployee } from '../iemployee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  list: Array<IEmployee> = [];
  constructor() { }

  getEmployeeList(): Array<IEmployee>{
    return this.list =[
      {
        age: 24,
      id :1,
      name:'Akshay',
      dob : new Date('19-Jan-1996')
      },
      {
        age: 25,
      id :2,
      name:'Akash',
      dob : new Date('19-Jan-1996')
      },
      {
      age: 26,
      id :3,
      name:'vijay',
      dob : new Date('19-Jan-1996')
      }
    ];
  }

  addEmployee(){
    this.list.push(
      {
        age:23,
        id : 6,
        name: 'Ajay',
        dob : new Date('19-Jan-1996')
      }
    );
  }
}
