import { Component, OnInit } from '@angular/core';
import { TodoService } from './todo.service';
import { ITodo } from './itodo';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  list: Array<ITodo> =[];

  constructor(private todoService: TodoService) { }

  ngOnInit() {
    this.todoService.getTodoList().subscribe((data)=>{
      this.list =data;
    }
     ,(err)=> console.log(err));
  }
  addTask(task: ITodo){
    this.todoService.addTask(task).subscribe(
      (data) => console.log(data)
    );
  }

}
