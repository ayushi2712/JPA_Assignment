import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators} from '@angular/forms';
import { ITodo } from '../itodo';

@Component({
  selector: 'app-todo-add',
  templateUrl: './todo-add.component.html',
  styleUrls: ['./todo-add.component.css']
})
export class TodoAddComponent implements OnInit {


  todoForm : FormGroup;
  @Output() saveTask = new EventEmitter<ITodo>();
  constructor(private fb : FormBuilder) { }

  ngOnInit() {
    this.todoForm = this.fb.group({
     userId: new FormControl('', Validators.required),
     title: new FormControl('',  Validators.required),
     body : new FormControl('',  Validators.required)
    });
  }

  addTask(){
    this.saveTask.emit(this.todoForm.getRawValue());
    //console.log(this.todoForm.getRawValue());
  }


}
