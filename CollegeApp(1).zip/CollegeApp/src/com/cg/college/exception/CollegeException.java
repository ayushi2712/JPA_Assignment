package com.cg.college.exception;

public class CollegeException extends Exception{


	public CollegeException()
	{
		
	}
	public CollegeException(String msg)
	{
		super(msg);
	}



}
