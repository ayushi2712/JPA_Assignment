package com.cg.college.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.college.bean.CollegeBean;
import com.cg.college.dao.ICollegeDao;





@Service
public class CollegeServiceImpl implements ICollegeService {
	@Autowired
	ICollegeDao studentDao;
	

	public ICollegeDao getStudentDao() {
		return studentDao;
	}

	public void setStudentDao(ICollegeDao studentDao) {
		this.studentDao = studentDao;
	}

	@Override
	public CollegeBean addStudent(CollegeBean student) {
		// TODO Auto-generated method stub
		//student.setDate(new Date());
		return studentDao.addStudent(student);
	}

	@Override
	public CollegeBean getStudentDetails(int StudentId) {
		// TODO Auto-generated method stub
		return studentDao.getStudentDetails(StudentId);
	}

	@Override
	public List<CollegeBean> getAllStudentDetails() {
		// TODO Auto-generated method stub
		return studentDao.getAllStudentDetails();
	}

	

	
}
