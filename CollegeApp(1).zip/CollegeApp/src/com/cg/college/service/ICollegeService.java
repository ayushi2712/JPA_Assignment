package com.cg.college.service;

import java.util.List;

import com.cg.college.bean.CollegeBean;

public interface ICollegeService {

	
	public CollegeBean addStudent(CollegeBean student);
	public CollegeBean getStudentDetails(int StudentId);
	public List<CollegeBean> getAllStudentDetails();
}
