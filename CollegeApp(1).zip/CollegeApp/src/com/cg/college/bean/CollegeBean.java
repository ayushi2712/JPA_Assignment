package com.cg.college.bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="college")
public class CollegeBean {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int StudentId;
	
	@NotEmpty(message="Please Enter student Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Username must contain only alphabets")
	private String StudentName;
	@Size(min=7,max=10,message="Phone Number Should Accept Only 10 digits")
	@Pattern(regexp = "^[0-9]+$", message = "Phone Number should contain only 10 digits")
	private String StudentPhoneNumber;
	@NotEmpty(message="Please Enter Address")
	private String StudentAddress;
	
	
	public int getStudentId() {
		return StudentId;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	public String getStudentPhoneNumber() {
		return StudentPhoneNumber;
	}
	public void setStudentPhoneNumber(String studentPhoneNumber) {
		StudentPhoneNumber = studentPhoneNumber;
	}
	public String getStudentAddress() {
		return StudentAddress;
	}
	public void setStudentAddress(String studentAddress) {
		StudentAddress = studentAddress;
	}
	@Override
	public String toString() {
		return "CollegeBean [StudentId=" + StudentId + ", StudentName="
				+ StudentName + ", StudentPhoneNumber=" + StudentPhoneNumber
				+ ", StudentAddress=" + StudentAddress + "]";
	}
	public CollegeBean(int studentId, String studentName,
			String studentPhoneNumber, String studentAddress) {
		super();
		StudentId = studentId;
		StudentName = studentName;
		StudentPhoneNumber = studentPhoneNumber;
		StudentAddress = studentAddress;
	}
public CollegeBean()
{
	
}
	
	
	
}
