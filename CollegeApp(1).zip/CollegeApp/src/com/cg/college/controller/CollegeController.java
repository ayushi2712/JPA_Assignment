package com.cg.college.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.college.bean.CollegeBean;
import com.cg.college.service.ICollegeService;










@Controller
public class CollegeController {
	
	@Autowired
	private ICollegeService studentService;

	public ICollegeService getStudentService() {
		return studentService;
	}

	public void setStudentService(ICollegeService studentService) {
		this.studentService = studentService;
	}

	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "index";
	}
	
	@RequestMapping("/showAddStudentForm")
	public ModelAndView showAddStudent() {
		// Create an attribute of type Question
		CollegeBean student = new CollegeBean();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addStudentForm", "student", student);
	}
	
	@RequestMapping("/addStudent")
	public ModelAndView addStudent(
					@ModelAttribute("student") @Valid CollegeBean student,
					BindingResult result) {

				ModelAndView mv = null;

				if (!result.hasErrors()) {
					student = studentService.addStudent(student);
					mv = new ModelAndView("addSuccess");
					mv.addObject("studentId", student.getStudentId());
					
				} else {
					mv = new ModelAndView("addStudentForm", "student", student);
				}

				return mv;
			}
	
	@RequestMapping("/showViewDonationForm")
	public ModelAndView showViewDonationForm() {

		// Create an attribute of type Question
		CollegeBean student = new CollegeBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewDonation");
		mv.addObject("student", student);
		mv.addObject("isFirst", "true");

		return mv;
	}
	
	@RequestMapping("/viewDonation")
	public ModelAndView viewDonation(@ModelAttribute("student") CollegeBean student) {

		ModelAndView mv = new ModelAndView();

		CollegeBean dBean = new CollegeBean();
		dBean = studentService.getStudentDetails(student.getStudentId());

		if (dBean != null) {
			mv.setViewName("viewDonation");
			mv.addObject("dBean", dBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	@RequestMapping("/showViewAllStudents")
	public ModelAndView showViewAllStudents() {

		ModelAndView mv = new ModelAndView();

		List<CollegeBean> list = studentService.getAllStudentDetails();
		if (list.isEmpty()) {
			String msg = "There are no students";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("ViewAllStudentsList");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
	}
	
}
