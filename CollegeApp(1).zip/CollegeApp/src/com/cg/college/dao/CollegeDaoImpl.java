package com.cg.college.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;



import org.springframework.stereotype.Repository;

import com.cg.college.bean.CollegeBean;




@Repository
@Transactional
public class CollegeDaoImpl implements ICollegeDao{
	
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public CollegeBean addStudent(CollegeBean student) {		
		entityManager.persist(student);
		entityManager.flush();
		return student;
	}

	@Override
	public CollegeBean getStudentDetails(int StudentId) {
		// TODO Auto-generated method stub
		 return entityManager.find(CollegeBean.class, StudentId);
	}

	@Override
	public List<CollegeBean> getAllStudentDetails() {
		// TODO Auto-generated method stub
		TypedQuery<CollegeBean> query = entityManager.createQuery("SELECT d from CollegeBean d", CollegeBean.class);
		return query.getResultList();
		
	}

}
