package com.cg.college.dao;

import java.util.List;

import com.cg.college.bean.CollegeBean;



public interface ICollegeDao {

	
	public CollegeBean addStudent(CollegeBean student);
	public CollegeBean getStudentDetails(int StudentId);
	public List<CollegeBean> getAllStudentDetails();
}
