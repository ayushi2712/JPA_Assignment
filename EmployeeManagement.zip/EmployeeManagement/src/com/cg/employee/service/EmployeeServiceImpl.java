package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.bean.EmployeeBean;
import com.cg.employee.dao.IEmployeeDao;

@Service
public class EmployeeServiceImpl implements IEmployeeService{
	@Autowired
	IEmployeeDao empDao;
	

	public IEmployeeDao getEmpDao() {
		return empDao;
	}

	public void setEmpDao(IEmployeeDao empDao) {
		this.empDao = empDao;
	}

	@Override
	public EmployeeBean addEmployee(EmployeeBean emp) {
		// TODO Auto-generated method stub
		return empDao.addEmployee(emp);
	}

	@Override
	public EmployeeBean getEmployeeDetails(int empId) {
		// TODO Auto-generated method stub
		return empDao.getEmployeeDetails(empId);
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails() {
		// TODO Auto-generated method stub
		return empDao.getAllEmployeeDetails();
	}

	




}
