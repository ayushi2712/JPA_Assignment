package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.bean.EmployeeBean;



public interface IEmployeeDao {
	public EmployeeBean addEmployee(EmployeeBean emp);
	public EmployeeBean getEmployeeDetails(int empId);
	public List<EmployeeBean> getAllEmployeeDetails();	
}
