package com.cg.employee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;






import org.springframework.stereotype.Repository;

import com.cg.employee.bean.EmployeeBean;



@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public EmployeeBean addEmployee(EmployeeBean emp) {
		// TODO Auto-generated method stub
		entityManager.persist(emp);
		entityManager.flush();
		return emp;
		
	}

	@Override
	public EmployeeBean getEmployeeDetails(int empId) {
		// TODO Auto-generated method stub
		return entityManager.find(EmployeeBean.class, empId);
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails() {
		// TODO Auto-generated method stub
		TypedQuery<EmployeeBean> query = entityManager.createQuery("SELECT e FROM EmployeeBean e", EmployeeBean.class);
		return query.getResultList();
		
	}

	}


