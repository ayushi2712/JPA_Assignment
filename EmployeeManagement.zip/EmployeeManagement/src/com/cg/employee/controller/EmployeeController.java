package com.cg.employee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.bean.EmployeeBean;
import com.cg.employee.service.IEmployeeService;



@Controller
public class EmployeeController {
	@Autowired
	private IEmployeeService empService;


	
	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "index";
	}
	@RequestMapping("/showAddEmployeeForm")
	public ModelAndView showAddEmployee() {
		// Create an attribute of type Question
		EmployeeBean emp = new EmployeeBean();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addEmployeeForm", "emp", emp);
		
	}
	@RequestMapping("/addEmployee")
	public ModelAndView addEmployee(
			@ModelAttribute("emp") @Valid EmployeeBean emp,
			BindingResult result) {

		ModelAndView mv = null;
		
		if (!result.hasErrors()) {
			emp = empService.addEmployee(emp);
			mv = new ModelAndView("addSuccess");
			mv.addObject("empId", emp.getEmpId());
			mv.addObject("empName", emp.getEmpName());
			mv.addObject("empsalary", emp.getEmpSalary());
		} else {
			mv = new ModelAndView("addEmployeeForm", "emp", emp);
		}

		return mv;
	}
	@RequestMapping("/showViewEmployeeForm")
	public ModelAndView showViewDonationForm() {

		// Create an attribute of type Question
		EmployeeBean emp = new EmployeeBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewEmployee");
		mv.addObject("emp", emp);
		mv.addObject("isFirst", "true");

		return mv;
	}
	@RequestMapping("/viewEmployee")
	public ModelAndView viewEmployee(@ModelAttribute("emp") EmployeeBean emp) {

		ModelAndView mv = new ModelAndView();

		EmployeeBean eBean = new EmployeeBean();
		eBean = empService.getEmployeeDetails(emp.getEmpId());

		if (eBean != null) {
			mv.setViewName("viewEmployee");
			mv.addObject("eBean", eBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	@RequestMapping("/showViewAllEmployee")
	public ModelAndView showViewAllEmployee() {

		ModelAndView mv = new ModelAndView();

		List<EmployeeBean> list = empService.getAllEmployeeDetails();
		if (list.isEmpty()) {
			String msg = "There are no Employee";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewAllEmployeeList");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
	}
	

}
